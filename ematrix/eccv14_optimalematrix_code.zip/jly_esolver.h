/********************************************************************
An implementation of the algorithm described in
"Optimal Essential Matrix Estimation via Inlier-Set Maximization"
Jiaolong Yang, Hongdong Li, Yunde Jia
European Conference on Computer Vision (ECCV), 2014

Last modified: Dec 23, 2014

Copyleft(Ɔ) 2014 Jiaolong Yang (BIT and ANU)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************/

#ifndef JLY_ESOLVER_H
#define JLY_ESOLVER_H

#include <queue>
#include <vector>
using namespace std;

//#include "Eigen/Dense"
//using namespace Eigen;
#include "matrix.h"

#define PI 3.1415926535898
#define SQRT3 1.732050808
#define SQRT2 1.414213562

/* 3D point structure */
typedef struct _POINT3D
{
	float x, y, z;
}POINT3D, *LPPOINT3D;

/* 5D cube structure */  
typedef struct _NODE
{
	/* Angle-axis paramters for R1 (c1 = 0) */
	float a1, b1;
	/* Angle-axis paramters for R2 */
	float a2, b2, c2; 
	/* Cube side length (NOT HALF LENGTH) */
	float w;
	/* Upper and lower bounds for the cube */
	unsigned short ub, lb;
	
	/* Comparison function (used by priority_queue) */
	friend bool operator < (const struct _NODE & n1, const struct _NODE & n2)
	{
		//Priority: 1. Upper bound  2. Cube Length  3. Lower Bound
		if(n1.ub != n2.ub)
			return n1.ub < n2.ub;
		else if(n1.w != n2.w)
			return n1.w < n2.w;
		else
			return n1.lb < n2.lb;
	}
}NODE, *LPNODE;

/********************************************************/

class ESolver
{
public:
	
	/* Parameters */
	double epsilon; // Angular error threshold in triangulation
	int boundsThresh; // Termination threshold between global lower and upper bounds

	/* Data */
	int Ntotal; // Total number of points
	LPPOINT3D u; // Nomalized points in the 1st camera
	LPPOINT3D v; // Nomalized points in the 2nd camera

	/* Functions */
	ESolver(); // Constructor
	int Solve(); // Main algorithm function

	/* Results */
	int Nopt; // Optimal inlier set cardinality
	vector<int> Iopt; // Optimal inlier set
	Matrix R1opt, R2opt; // Optimal camera absolute rotations
	Matrix Eopt; // Optimal essential matrix

private:
	NODE nodeSol; // the 5D cube containing the optimal solution. [-pi, pi]^5 by default; can be changed (e.g. to a much smaller cube centred at an initial solution?)
	priority_queue<NODE> queueNode; // Queue
	int initSizePerDim; // Inital cude division in each dimension; 6 by default

	/* Initialization: divide the initial cube into smaller cubes
	   and put them into initial queue */
	void Initialize();
	/* Test whether the triangulation of correspondence u_i<->v_i is feasible
	   with current rotation and threshold parameters */
	inline bool Feasible(double theta1, double phi1, double theta2, double phi2, double e1, double e2);
	/* Convert angle-axis paramters to a rotation matrix */
	inline void r2R(double r1, double r2, double r3,
			 double& R11, double& R12, double& R13,
			 double& R21, double& R22, double& R23,
			 double& R31, double& R32, double& R33);
};

#endif