/********************************************************************
An implementation of the algorithm described in
"Optimal Essential Matrix Estimation via Inlier-Set Maximization"
Jiaolong Yang, Hongdong Li, Yunde Jia
European Conference on Computer Vision (ECCV), 2014

Last modified: Dec 23, 2014

Copyleft(Ɔ) 2014 Jiaolong Yang (BIT and ANU)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************/

#include <stdio.h>
#include <math.h>
#include <iostream>
using namespace std;

#include "jly_esolver.h"

#define ASSURE(x) (x>1?1:(x<-1?-1:x))

ESolver::ESolver()
{
	nodeSol.a1 = nodeSol.b1 = nodeSol.a2 = nodeSol.b2 = nodeSol.c2 = -PI;
	nodeSol.w = 2*PI;

	initSizePerDim = 6;

	Nopt = 4;
}

/* Test whether the triangulation of correspondence u_i<->v_i is feasible
   with current rotation and threshold parameters */
inline bool ESolver::Feasible(double theta1, double phi1, double theta2, double phi2, double e1, double e2)
{
	/* Condition 1: theta <= theta' + 2*epsilon */
	if(theta1 > theta2 +e1+e2)
		return false;

	double w;
	/* if w ill-defined */
	if(theta1 < e1 || theta2 < e2 || theta1 > PI-e1 || theta2 > PI-e2) 
	{
		return true; 
		w = PI;
	}
	else if(theta1 < theta2)
	{
		w = asin(sin(e1)/sin(theta1)) + asin(sin(e2)/sin(theta2));
	}
	else
	{
		double temp = (cos(e1+e2)-cos(theta1)*cos(theta2))/(sin(theta1)*sin(theta2));
		if(temp > 1 || temp < -1)
			return true;
		w = acos( temp );
	}

	/* Condition 2: phi \in [phi'-w, phi'+w] */
	double tmp = abs(phi1-phi2);
	if(tmp > PI)
		tmp = 2*PI - tmp;
	if( tmp > w )
		return false;

	return true;
}

/* Convert angle-axis paramters to a rotation matrix */
inline void ESolver::r2R(double v1, double v2, double v3,
					double& R11, double& R12, double& R13,
					double& R21, double& R22, double& R23,
					double& R31, double& R32, double& R33)
{
	double t, ct, ct2,st, st2;
	double tmp121, tmp122, tmp131, tmp132, tmp231, tmp232;
	t = sqrt(v1*v1 + v2*v2 + v3*v3);

	if(t > 0)
	{
		v1 /= t;
		v2 /= t;
		v3 /= t;

		ct = cos(t);
		ct2 = 1 - ct;
		st = sin(t);
		st2 = 1 - st;

		//R11 = ct + v1*v1*ct2;		R12 = v1*v2*ct2 - v3*st;	R13 = v1*v3*ct2 + v2*st;
		//R21 = v1*v2*ct2 + v3*st;	R22 = ct + v2*v2*ct2;		R23 = v2*v3*ct2 - v1*st;
		//R31 = v1*v3*ct2 - v2*st;	R32 = v2*v3*ct2 + v1*st;	R33 = ct + v3*v3*ct2;

		tmp121 = v1*v2*ct2; tmp122 = v3*st;
		tmp131 = v1*v3*ct2; tmp132 = v2*st;
		tmp231 = v2*v3*ct2; tmp232 = v1*st;

		R11 = ct + v1*v1*ct2;		R12 = tmp121 - tmp122;		R13 = tmp131 + tmp132;
		R21 = tmp121 + tmp122;		R22 = ct + v2*v2*ct2;		R23 = tmp231 - tmp232;
		R31 = tmp131 - tmp132;		R32 = tmp231 + tmp232;		R33 = ct + v3*v3*ct2;

	}
	else
	{
		R11 = R22 = R33 = 1;
		R12 = R13 = R21 = R23 = R31 = R32 = 0;
	}
}

/* Initialization: divide the initial cube into smaller cubes
   and put them into initial queue */
void ESolver::Initialize()
{
	int i,j,k,l,m;
	double len;
	NODE node;

	len = nodeSol.w/initSizePerDim;
	node.w = len;
	node.ub = Ntotal;
	node.lb = 0;
	for(i = 0; i < initSizePerDim; i++)
		for(j = 0; j < initSizePerDim; j++)
			for(k = 0; k < initSizePerDim; k++)
				for(l = 0; l < initSizePerDim; l++)
					for(m = 0; m < initSizePerDim; m++)
					{
						node.a1 = nodeSol.a1 + i*len;
						node.b1 = nodeSol.b1 + j*len;
						node.a2 = nodeSol.a2 + k*len;
						node.b2 = nodeSol.b2 + l*len;
						node.c2 = nodeSol.c2 + m*len;

						queueNode.push(node);
					}

}


/* Main function to solve the problem */
int ESolver::Solve()
{
	NODE nodeParent, node;
	int i, ii;
	double r1, r2, r3;
	int lb, ub;
	double R11, R12, R13, R21, R22, R23, R31, R32, R33;
	double R11_, R12_, R13_, R21_, R22_, R23_, R31_, R32_, R33_;
	double Ropt11, Ropt12, Ropt13, Ropt21, Ropt22, Ropt23, Ropt31, Ropt32, Ropt33;
	double Ropt11_, Ropt12_, Ropt13_, Ropt21_, Ropt22_, Ropt23_, Ropt31_, Ropt32_, Ropt33_;
	double u1, u2, u3, v1, v2, v3;
	double theta1, phi1, theta2, phi2, relax1, relax2;
	double w2;

	Initialize();
	
	cout << "|I| = " << Nopt << " (Init)" << endl;
	while(1)
	{
		if(queueNode.empty())
			break;

		nodeParent = queueNode.top();
		queueNode.pop();

		if((nodeParent.ub-Nopt) <= boundsThresh)
			break;

		node.w = nodeParent.w/2;
		w2 = node.w/2;
		relax1 = SQRT2*w2;
		relax2 = SQRT3*w2;

		for(ii = 0; ii < 32; ii++)
		{

			node.a1 = nodeParent.a1 + (ii&1)*node.w;
			node.b1 = nodeParent.b1 + (ii>>1&1)*node.w;
			node.a2 = nodeParent.a2 + (ii>>2&1)*node.w;
			node.b2 = nodeParent.b2 + (ii>>3&1)*node.w;
			node.c2 = nodeParent.c2 + (ii>>4&1)*node.w;

			r1 = node.a1+w2; r2 = node.b1+w2; r3 = 0;
			if(sqrt(r1*r1+r2*r2+r3*r3) > PI+SQRT2*w2)
				continue;
			r2R(r1, r2, r3, R11, R12, R13, R21, R22, R23, R31, R32, R33);

			r1 = node.a2+w2; r2 = node.b2+w2; r3 = node.c2+w2;
			if(sqrt(r1*r1+r2*r2+r3*r3) > PI+SQRT3*w2)
				continue;
			r2R(r1, r2, r3, R11_, R12_, R13_, R21_, R22_, R23_, R31_, R32_, R33_);
			
			lb = ub = 0;
			for(i = 0; i < Ntotal; i++)
			{
				u1 = R11 *u[i].x + R21 *u[i].y + R31 *u[i].z;
				u2 = R12 *u[i].x + R22 *u[i].y + R32 *u[i].z;
				u3 = R13 *u[i].x + R23 *u[i].y + R33 *u[i].z;

				v1 = R11_*v[i].x + R21_*v[i].y + R31_*v[i].z;
				v2 = R12_*v[i].x + R22_*v[i].y + R32_*v[i].z;
				v3 = R13_*v[i].x + R23_*v[i].y + R33_*v[i].z;

				u3 = ASSURE(u3);
				v3 = ASSURE(v3);

				theta1 = acos(u3);
				phi1 = atan2(u2,u1);
				theta2 = acos(v3);
				phi2 = atan2(v2,v1);

				if(Feasible(theta1, phi1, theta2, phi2, epsilon+relax1, epsilon+relax2))
				{
					ub ++;
					if(Feasible(theta1, phi1, theta2, phi2, epsilon, epsilon))
						lb ++;
				}
				else if(ub + (Ntotal-i-1) <= Nopt)
				{
					break;
				}
			}

			if(ub <= Nopt)
				continue; //discard

			if(lb > Nopt)
			{
					
				Nopt = lb;
				cout << "|I| = " << Nopt << endl;

				Ropt11 = R11; Ropt12 = R12; Ropt13 = R13; Ropt21 = R21; Ropt22 = R22; Ropt23 = R23; Ropt31 = R31; Ropt32 = R32;  Ropt33 = R33; 
				Ropt11_ = R11_; Ropt12_ = R12_; Ropt13_ = R13_; Ropt21_ = R21_; Ropt22_ = R22_; Ropt23_ = R23_; Ropt31_ = R31_; Ropt32_ = R32_;  Ropt33_ = R33_; 

				priority_queue<NODE> queueTemp;
				while(!queueNode.empty())
				{
					NODE nodeTemp = queueNode.top();
					queueNode.pop();
					if(nodeTemp.ub > Nopt)
						queueTemp.push(nodeTemp);
				}
				queueNode = queueTemp;
			}

			node.lb = lb;
			node.ub = ub;
			queueNode.push(node);
		}
	}

	cout << endl << "|I*| = " << Nopt << endl;
	Iopt.clear();
	for(i = 0; i < Ntotal; i++)
	{
		u1 = Ropt11 *u[i].x + Ropt21 *u[i].y + Ropt31 *u[i].z;
		u2 = Ropt12 *u[i].x + Ropt22 *u[i].y + Ropt32 *u[i].z;
		u3 = Ropt13 *u[i].x + Ropt23 *u[i].y + Ropt33 *u[i].z;

		v1 = Ropt11_*v[i].x + Ropt21_*v[i].y + Ropt31_*v[i].z;
		v2 = Ropt12_*v[i].x + Ropt22_*v[i].y + Ropt32_*v[i].z;
		v3 = Ropt13_*v[i].x + Ropt23_*v[i].y + Ropt33_*v[i].z;

		u3 = ASSURE(u3);
		v3 = ASSURE(v3);

		theta1 = acos(u3);
		phi1 = atan2(u2,u1);
		theta2 = acos(v3);
		phi2 = atan2(v2,v1);

		if(Feasible(theta1, phi1, theta2, phi2, epsilon, epsilon))
		{
			Iopt.push_back(i);
			cout << i << " ";
		}
	}
	cout << endl;

	R1opt = Matrix(3,3);
	R1opt.val[0][0] = Ropt11; R1opt.val[0][1] = Ropt12; R1opt.val[0][2] = Ropt13;
	R1opt.val[1][0] = Ropt21; R1opt.val[1][1] = Ropt22; R1opt.val[1][2] = Ropt23;
	R1opt.val[2][0] = Ropt31; R1opt.val[2][1] = Ropt32; R1opt.val[2][2] = Ropt33;
	R2opt = Matrix(3,3);
	R2opt.val[0][0] = Ropt11_; R2opt.val[0][1] = Ropt12_; R2opt.val[0][2] = Ropt13_;
	R2opt.val[1][0] = Ropt21_; R2opt.val[1][1] = Ropt22_; R2opt.val[1][2] = Ropt23_;
	R2opt.val[2][0] = Ropt31_; R2opt.val[2][1] = Ropt32_; R2opt.val[2][2] = Ropt33_;
	Matrix Rrel = R2opt*(~R1opt); // R = R2*R1^t
	Matrix Trel = R2opt.getMat(0,2,2,2) * -1; // T = -R2*[0,0,1]^T
	Matrix TrelSkew = Matrix(3,3);
	TrelSkew.zero();
	                                      TrelSkew.val[0][1] = -Trel.val[2][0];  TrelSkew.val[0][2] = Trel.val[1][0];
	TrelSkew.val[1][0] = Trel.val[2][0];                                         TrelSkew.val[1][2] = -Trel.val[0][0];
	TrelSkew.val[2][0] = -Trel.val[1][0];  TrelSkew.val[2][1] = Trel.val[0][0];
	Eopt = TrelSkew*Rrel;

	//cout << Rrel << endl << Trel << endl << TrelSkew;
	cout << "R1 =" << endl << R1opt << endl;
	cout << "R2 =" << endl << R2opt << endl;
	cout << "E =" << endl << Eopt << endl;

	return Nopt;
}