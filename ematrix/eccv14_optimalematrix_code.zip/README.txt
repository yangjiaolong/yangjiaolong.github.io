This is a naive implementation of the essential matrix estimation algorithm described in our paper:
"Jiaolong Yang, Hongdong Li and Yunde Jia, Optimal Essential Matrix Estimation via Inlier-Set Maximization, European Conference on Computer Vision (ECCV), 2014".

To deal with real-world cases one may need some strategies such as multi-thread speedup. Multi-threading was used in the experiments of our paper for real data, however I found my implementation crude and inefficient thus it is not included.

License: GNU General Public License (GPL) v3.


Jiaolong Yang