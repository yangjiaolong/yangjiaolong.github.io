/********************************************************************
An implementation of the algorithm described in
"Optimal Essential Matrix Estimation via Inlier-Set Maximization"
Jiaolong Yang, Hongdong Li, Yunde Jia
European Conference on Computer Vision (ECCV), 2014

Last modified: Dec 23, 2014

Copyleft(Ɔ) 2014 Jiaolong Yang (BIT and ANU)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************/

#include <time.h>
#include <iostream>
#include <fstream>
using namespace std;

#include "jly_esolver.h"

int main(int argc, char * argv[])
{
	if(argc < 4)
	{
		cout << "USAGE: EMatrix.exe <POINT_FILE> <RESULT_FILE> <EPSILON> <INIT_INLIER_NUM>(optional, delfault 4) <BOUND_THRESHOLD>(optional, delfault 0)"
			<< endl;
		return -1;
	}

	double epsilon = atof(argv[3]); // Angular error threshold in triangulation. 0.00175 rad ~= 0.1 deg
	int Nopt = argc > 4 ? atoi(argv[4]) : 4; // Initial inlier number 
	int boundsThresh = argc > 5 ? atoi(argv[5]) : 0; // Termination threshold between global lower and upper bounds
	
	int N, i;
	ifstream ifile;
	ifile.open(argv[1], ifstream::in);
	ifile >> N;
	LPPOINT3D u = (LPPOINT3D)malloc(sizeof(POINT3D)*N);
	for(i = 0; i < N; i++)
		ifile >> u[i].x >> u[i].y >> u[i].z;
	LPPOINT3D v = (LPPOINT3D)malloc(sizeof(POINT3D)*N);
	for(i = 0; i < N; i++)
		ifile >> v[i].x >> v[i].y >> v[i].z;

	ESolver solver;
	//data
	solver.Ntotal = N;
	solver.u = u;
	solver.v = v;
	//param
	solver.epsilon = epsilon;
	solver.Nopt = Nopt;
	solver.boundsThresh = boundsThresh;


	clock_t  clockBegin, clockEnd;
	cout << "Begin..." << endl;
	clockBegin = clock();
	solver.Solve();
	clockEnd = clock();
	float t = (clockEnd - clockBegin)*1.0/CLOCKS_PER_SEC;
	cout << "Finished in " << t << "s" << endl;


	ofstream ofile;
	ofile.open(argv[2], ofstream::out);
	ofile << solver.Nopt << endl;
	for(i = 0; i < solver.Nopt; i++)
		ofile << solver.Iopt[i] << " "; // Note: id starts with 0 (rather than 1)
	ofile << endl;
	ofile << solver.R1opt << endl << solver.R2opt << endl << solver.Eopt << endl;
	ofile.close();

	delete(u);
	delete(v);

	return 0;
}